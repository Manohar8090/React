import { useSelector, useDispatch } from "react-redux";
import AddForm from "./AddForm";
import { deleteTodo, marksAsDone } from "../Features/Todos/TodoSlice";

export default function Todo() {
  const todos = useSelector((state) => state.todos);
  console.log(todos);
  const dispatch = useDispatch();

  const clickHandler = (id) => {
    console.log("delete", id);
    dispatch(deleteTodo(id));
  };

  const handler = (id) => {
    console.log("marksAsDone", id);
    dispatch(marksAsDone(id));
  };

  return (
    <>
      <AddForm />
      <h2>Todo List App</h2>
      <ul>
        {todos.map((todo) => (
          <li key={todo.id}>
            <span
              style={{
                textDecoration: todo.isDone ? "line-through" : "none",
              }}
            >
              {todo.task}
            </span>
            <button onClick={() => clickHandler(todo.id)}>Delete</button>
            <button onClick={() => handler(todo.id)}>MarkAsDone</button>
          </li>
        ))}
      </ul>
    </>
  );
}
